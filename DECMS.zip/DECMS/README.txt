WELCOME TO DeCMS

DeCMS is a tool that is aimed to help you, the intrepid user, to download and archive websites. 

*************************
----How to use DeCMS:----
*************************

----HOME----
In the middle of the home page, a list of all the downloaded websites is displayed. 
At the top right of the home page, there are some drop down menus, this is what they do:

>File:
In the file dropdown menu
>>New URL:
This opens up the download panel.
>>Open: 
This brings up the file browser and can be used to open up any of the downloaded websites. 
>>Settings:
This is where the settings are. 
>>Exit:
Exit close the program. Clicking the X at the top right of the application will also do this. 

>Edit:
>>Clear Recent Download History:
This deletes the download history. And we all know why that is important. :^)

>Help:
>>View README:
This displays the very ReadMe.txt that you are reading now! Congratulations! 

----DOWNLOAD PANEL----
This is the bread and butter of this program; as this is how we go about starting a new download, and downloading a website.
Once we have selected this option, a new new display will be shown. 
Front and centre, is the text box where the URL must be entered. 
To the right of this, is a button that allows the user to select the directory in which they wish the website to be saved. 
Bottom left is the download button. The download only begins after this button is pressed. 
Bottom right is the cancel button, this cancels the download and closes the dialog once pressed. 
If the open file after download tick box is ticked, then the file will be opened after it is downloaded. 

