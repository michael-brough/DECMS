// DeCMS
// CSC3003S 2020

// Imports
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.lang.*;
import java.net.URL;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import org.jsoup.nodes.*;
import org.jsoup.Jsoup;
import org.jsoup.select.*;

/**
 * Class designed to handle all file downloads, extends Thread class for multithreaded downloads.
 */
public class DownloadThread extends Thread {
    // Instance variables
    private String URl;
    private JPanel p;
    private boolean open;
    private String type;
    private int count;
    private String pathName;
    private String fileName;
    private String userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)";
    private ArrayList<String> settingsArray = new ArrayList<>();
    private boolean goodLink = true;

    /**
     * Constructor that assigns variables
     *
     * @param tempurl  the web address from which files will be downloaded
     * @param panel    the panel object from the GUI
     * @param bool     a boolean that dictates whether or not the file should open in the browser after the download
     * @param type     the type of file to be downloaded
     * @param pathName the path of the directory to where the files will be downloaded
     */
    public DownloadThread(String tempurl, JPanel panel, boolean bool, String type, String pathName) {
        URl = tempurl;
        p = panel;
        open = bool;
        this.type = type;
        this.pathName = pathName;
    }


    /**
     * Constructor that assigns variables
     *
     * @param tempurl  the web address from which files will be downloaded
     * @param type     the type of file to be downloaded
     * @param fileName the name that the file should be saved as
     * @param pathName the path of the directory to where the files will be downloaded
     */
    public DownloadThread(String tempurl, String type, String fileName, String pathName) {
        URl = tempurl;
        this.type = type;
        this.fileName = fileName;
        this.pathName = pathName;
    }

    /**
     * run method which is called when the thread is started
     * checks what type of file is to be downloaded and applies the most appropriate method call
     */
    public void run() {
        readSettings();
        String tempAgent = settingsArray.get(2);
        tempAgent = tempAgent.substring(tempAgent.indexOf("=") +1);
        userAgent = tempAgent;
        try {
            if (type.equals("image")) {
                downloadImage(URl);
            } else if (type.equals(".css")) {
                downloadCSS();
                //System.out.println("StyleSheet Downloaded");
            } else {
                download(URl);
                //System.out.println("Link Downloaded");
            }
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

    /**
     * method which downloads .css files
     * checks what type of file is to be downloaded and applies the most appropriate method call
     */
    public void downloadCSS() throws IOException {
        String path = pathName + "\\styling\\" + this.fileName;
        Document doc = null;

        //prevents websites from blocking the download thinking that it is a bot attack
        try {
            doc = Jsoup.connect(URl).ignoreContentType(true)
                    .userAgent(userAgent)
                    .referrer("http://www.google.com")
                    .get();
        } catch (IOException e) {
            //e.printStackTrace();
        }

        BufferedWriter cssWriter = new BufferedWriter(new FileWriter(path));
        cssWriter.write(doc.toString());
        cssWriter.flush();
    }

    /**
     * method to download image files
     *
     * @param url the URL from which the files will be downloaded
     * @throws IOException
     */
    public void downloadImage(String url) throws IOException {
        try (InputStream in = new URL(url).openStream()) {
            Files.copy(in, Paths.get(pathName + "\\images\\" + fileName));
        } catch (FileAlreadyExistsException e) {
            // The program will not save any files that already exist
        }
    }

    public void getRobot(String url) throws IOException {
        Document doc = null;

        try {
            doc = Jsoup.connect(url.concat("/robots.txt")).ignoreContentType(true)
                    .userAgent(userAgent)
                    .referrer("http://www.google.com")
                    .get();
        } catch (Exception ignored) {}

        try {
            BufferedWriter robotWriter = new BufferedWriter(new FileWriter(pathName + "\\robot.txt"));
            robotWriter.write(doc.toString());
            robotWriter.flush();
        }catch(Exception ignored) {}
    }

    /**
     * method to download websites
     *
     * @param urlString the URL from which the files will be downloaded
     * @throws IOException
     */
    public void download(String urlString) throws IOException {
        //href link scraper
        Document doc = null;
        //Main main = new Main();

        try {
            doc = Jsoup.connect(urlString).ignoreContentType(true)
                    .userAgent(userAgent)
                    .referrer("http://www.google.com")
                    .get();
        } catch (IOException e) {
            //e.printStackTrace();
            goodLink = false;
        }
        if(goodLink){
            Elements links = doc.select("a[href]"); // a with href

            if (this.type.equals("site")) {
                String path = pathName + "\\links\\" + fileName + ".html";

                BufferedWriter HTMLWriter = new BufferedWriter(new FileWriter(path));
                HTMLWriter.write(doc.toString());
                HTMLWriter.flush();
            } else {
                File file = new File(pathName);
                //Creating the directory
                boolean bool = file.mkdir();
                BufferedWriter linkWriter = new BufferedWriter(new FileWriter(pathName.concat("\\links.txt")));
                BufferedWriter HTMLWriter = new BufferedWriter(new FileWriter(pathName.concat("\\htmlFull.html")));
                HTMLWriter.write(doc.toString());
                HTMLWriter.flush();

                for (Element link : links) {

                    linkWriter.write(link.toString() + '\n');
                    linkWriter.flush();
                }
                getRobot(urlString);
            }

        }

    }

    /**
     * Setter for the userAgent variable
     * @param agent the input parameter which will be assigned to userAgent
     */
    public void setUserAgent(String agent){
        userAgent = agent;
    }

    /**
     * method to open the html file in the user's default browser
     *
     * @throws IOException
     */
    public void openFile(String path) throws IOException {
        File file = new File(path); // change this
        if (!Desktop.isDesktopSupported())//check if Desktop is supported by Platform or not
        {
            //System.out.println("not supported");
            return;
        }
        Desktop desktop = Desktop.getDesktop();
        if (file.exists())         //checks file exists or not
            desktop.open(file);              //opens the specified file

    }

    /**
     * Method to read settings.txt and save them in the settingsArray ArrayList
     * The settingsArray list is used to check current application settings
     */
    public void readSettings(){
        try (Scanner s = new Scanner(new FileReader("settings.txt"))) {
            while (s.hasNext()) {
                settingsArray.add(s.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * returns the goodLink variable - lets program know not to try to continue downloading a link that does not send a response
     * @return
     */
    public boolean getGoodLink(){
        return goodLink;
    }
}
