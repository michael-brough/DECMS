// DeCMS
// CSC3003S 2020

// Imports
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * GUI to display and change application settings.
 * Settings to change the default download directory, preferred user agent, and number of layers deep the application should download
 * Also includes button to reset settings to their default values and a close button to close the window.
 */
public class SettingsGUI extends JFrame {
    // Instance Variables
    private JPanel newPanel;
    private JLabel defaultDirLabel;
    private JButton chooseDefaultDir;
    private JFileChooser chooser;
    private JLabel userAgentLabel;
    private JComboBox selectUserAgent;
    private String[] userAgentOptionsSimplified = {"Google Chrome", "Mozilla Firefox", "Microsoft Edge", "Apple iPhone", "Samsung Phone"};
    private String[] userAgentOptions = {"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:53.0) Gecko/20100101 Firefox/53.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393", "Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1", "Mozilla/5.0 (Linux; Android 6.0.1; SAMSUNG SM-G570Y Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/44.0.2403.133 Mobile Safari/537.36"};
    private JLabel linkLayerLabel;
    private String[] linkLayerList = {"One", "As Far as Possible"};
    private JComboBox linkLayerBox;
    private JLabel emptyLabel;
    private JButton resetButton;
    private JButton closeButton;
    private String directory;
    protected Boolean default_Dir;
    private final String settings = "settings.txt";
    private ArrayList<String> settingsArray;
    private FileWriter fw;
    private PrintWriter pw;

    // choosing user agent
    // choose default directory
    // select how many layers deep the links should traverse

    /**
     * Default Constructor to initialise the User Interface
     */
    public SettingsGUI() {
        settingsArray = new ArrayList<>();
        getSettingsFromFile();
        initUI();

    }

    /**
     * Method to configure the GUI elements (i.e. components and panels)
     * GUI uses Grid Layout to space each button equally
     */
    public void initUI() {
        setTitle("DeCMS Settings");
        setSize(450, 200);
        setLocationRelativeTo(null);
        setVisible(true);
        newPanel = new JPanel();
        newPanel.setLayout(new GridLayout(4,2, 4, 4));
        newPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Configuration Menu"));
        add(newPanel);
        defaultDirLabel = new JLabel("Select a Default Download Directory:");
        defaultDirLabel.setToolTipText("All of your downloaded websites will appear in the chosen location");
        newPanel.add(defaultDirLabel);
        chooseDefaultDir = new JButton("Choose Directory");
        chooseDefaultDir.setToolTipText("All of your Downloaded Websites will Appear in the Chosen Location");
        newPanel.add(chooseDefaultDir);
        userAgentLabel = new JLabel("Select a UserAgent from the List:");
        selectUserAgent = new JComboBox(userAgentOptionsSimplified);
        selectUserAgent.setToolTipText("Only change this if you know what you're doing");
        newPanel.add(userAgentLabel);
        newPanel.add(selectUserAgent);
        linkLayerLabel = new JLabel("How Deep (Layers) for Link Downloads:");
        linkLayerBox = new JComboBox(linkLayerList);
        linkLayerBox.setToolTipText("Warning: Could Cause Unexpected Issues with the Web Server");
        newPanel.add(linkLayerLabel);
        newPanel.add(linkLayerBox);
        resetButton = new JButton("Reset to Default Settings");
        resetButton.setToolTipText("Reset all Settings to Default Values");
        newPanel.add(resetButton, BOTTOM_ALIGNMENT);
        closeButton = new JButton("Close");
        newPanel.add(closeButton);
        newPanel.setVisible(true);
        // update gui according to settings
        setSelectedIndicesFromSettings();


        // when the button is clicked, a file chooser is opened and allows the user to select the default directory
        chooseDefaultDir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chooser = new JFileChooser();
                chooser.setDialogTitle("Select Default Directory");
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                // Disable the "all files" option
                chooser.setAcceptAllFileFilterUsed(false);

                if (chooser.showOpenDialog(newPanel) == JFileChooser.APPROVE_OPTION) {
                    directory = "" + chooser.getSelectedFile();
                    default_Dir = true;
                    writeSettingToFile(0, "default_dir=" + directory);
                    writeSettingToFile(1, "dir_settings_changed=true");

                } else {
                    default_Dir = false;
                }
            }
        });

        // when clicked, selects the appropriate useragent according to the index of the selection
        selectUserAgent.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int i = selectUserAgent.getSelectedIndex();
                writeSettingToFile(2, "userAgent=" + userAgentOptions[i]);
            }
        });

        // when clicked, resets the settings back to the default values
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int reply = JOptionPane.showConfirmDialog(null, "You are about to reset the setting to their default values.\nContinue?", "Reset Settings", JOptionPane.YES_NO_OPTION);
                if (reply == JOptionPane.YES_OPTION) {
                    writeDefaultSettings();
                    getSettingsFromFile();
                    setSelectedIndicesFromSettings();
                } else {
                    //do nothing
                }
            }
        });

        // when clicked, changes the number of layers deep into the website the code must traverse and download
        linkLayerBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int i = linkLayerBox.getSelectedIndex();
                writeSettingToFile(3, "linkLayers=" + linkLayerList[i]);
            }
        });

        // when clicked, closes the settingsGUI window
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    /**
     * Getter for the default_Dir boolean. This boolean keeps track of if the default directory has been set or not.
     * @return default_Dir
     */
    public Boolean getDefault_Dir() {
        return default_Dir;
    }

    /**
     * Method to read in the settings text file and add each line to the settingsArray ArrayList
     * @return ArrayList containing all of the application settings
     */
    public ArrayList<String> getSettingsFromFile() {

        try (Scanner scanner = new Scanner(new FileReader(settings))) {
            while (scanner.hasNext()) {
                settingsArray.add(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return settingsArray;
    }

    /**
     * Method to write the contents of the settingsArray list to the settings text file
     * @param index the index of the ArrayList where data should be replaced
     * @param value the settings string which needs to be written to the text file
     * @throws NullPointerException
     */
    public void writeSettingToFile(int index, String value) throws NullPointerException {
        try {
            settingsArray.set(index, value);
        } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            settingsArray.add(value);
        }

        try {
            pw = new PrintWriter(settings);

            for (int i = 0; i < settingsArray.size(); i++) {
                pw.println(settingsArray.get(i));
            }
            pw.close();
        } catch (Exception e) {
            e.printStackTrace();
            //System.out.println("No such file exists.");
        }
    }

    /**
     * Method to alter the settings text file back to their default values.
     */
    public void writeDefaultSettings() {
        writeSettingToFile(0, "default_dir=null");
        writeSettingToFile(1, "dir_settings_changed=false");
        writeSettingToFile(2, "userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36");
        writeSettingToFile(3, "linkLayers=One");
        settingsArray.clear();

    }

    /**
     * Method that checks the current settings and updates the UI's currently selected options, letting the user know
     * what each option is currently set to
     */
    public void setSelectedIndicesFromSettings(){
        // check what the userAgent is set as
        switch(settingsArray.get(2)){
            case "userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36":
                selectUserAgent.setSelectedIndex(0);
                break;
            case "userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:53.0) Gecko/20100101 Firefox/53.0":
                selectUserAgent.setSelectedIndex(1);
                break;
            case "userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393":
                selectUserAgent.setSelectedIndex(2);
                break;
            case "userAgent=Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1":
                selectUserAgent.setSelectedIndex(3);
                break;
            case "userAgent=Mozilla/5.0 (Linux; Android 6.0.1; SAMSUNG SM-G570Y Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/44.0.2403.133 Mobile Safari/537.36":
                selectUserAgent.setSelectedIndex(4);
                break;
        }
        // check what the number of layers is set as
        if(settingsArray.get(3).equals("linkLayers=One")){
            linkLayerBox.setSelectedIndex(0);
        }
        else{
            linkLayerBox.setSelectedIndex(1);
        }
    }
}
