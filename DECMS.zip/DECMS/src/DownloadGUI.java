// DeCMS
// CSC3003S 2020

// Imports

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Initializes the interface, takes in input from the user for which website to download with the textField object.
 * Clicking on the interface's download button calls the downloadThread class and starts the download.
 * There is a button to select the file directory to which the files will be downloaded, which, when clicked, will open a fileChooser.
 * There is a check-box which, if selected, will open the website in your default browser once it has been downloaded.
 * The cancel button will close the window.
 */
public class DownloadGUI extends JFrame {

    // Instance Variables for the GUI
    private JLabel labelUrl = new JLabel("Enter URL: ");
    private JTextField textUrl = new JTextField(20);
    private JButton download = new JButton("Download");
    private JButton chooseDir = new JButton("Choose Directory");
    private JCheckBox checkbox = new JCheckBox("Open file after download");
    private boolean open = false;
    private JPanel newPanel;
    private JButton cancel = new JButton("Cancel");
    private String domain = "";
    private String dir = ".";
    private JFileChooser chooser = new JFileChooser();
    private String chooserTitle;
    private boolean default_Dir = false;
    private String filler = "https://";
    private String directory = "";
    private FileWriter fw;
    private BufferedWriter bw;
    private PrintWriter pw;
    private DateTimeFormatter dtf;
    private ArrayList<String> settingsArray;

    /**
     * Default Constructor to initialise the GUI elements and action listeners
     */
    public DownloadGUI() {
        super("DeCMS Website Downloader");

        // create a new panel with GridBagLayout manager
        newPanel = new JPanel(new GridBagLayout());

        // Check box is to true by default
        checkbox.setSelected(false);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(10, 10, 10, 10);

        // add components to the panel
        constraints.gridx = 0;
        constraints.gridy = 0;
        newPanel.add(labelUrl, constraints);

        constraints.gridx = 1;
        newPanel.add(textUrl, constraints);

        constraints.gridy = 1;
        constraints.gridx = 0;
        newPanel.add(checkbox, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.WEST;
        newPanel.add(download, constraints);

        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        //newPanel.add(progressBar, constraints);

        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.EAST;
        newPanel.add(cancel, constraints);

        newPanel.add(chooseDir);
        chooser.setCurrentDirectory(new File("."));

        // Checks if Default Settings Have been Changed
        settingsArray = new ArrayList<>();
        readSettings();
        if (settingsArray.get(1).equals("dir_settings_changed=false")) {
            download.setEnabled(false);
        } else {
            download.setEnabled(true);
            String newDirectory = settingsArray.get(0);
            directory = newDirectory.substring(12);
        }
        // check if the text box has text in it before user is allowed to click download
        int delay = 500;
        Timer timer = new Timer(delay, e -> {
            if (textUrl.getText().length() > 0 && directory != "" && textUrl.getText().contains(":") == false) {
                download.setEnabled(true);
            } else {
                download.setEnabled(false);
            }
        });
        timer.start();

        // Activates User tooltip if directory has not yet been selected.
        if (download.isEnabled() == false) {
            download.setToolTipText("Select a Directory");
        }

        // Action Listener which manages the directory chooser GUI.
        chooseDir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //chooser = new JFileChooser();
                chooser.setDialogTitle(chooserTitle);
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                // Disable the "all files" option
                chooser.setAcceptAllFileFilterUsed(false);

                if (chooser.showOpenDialog(newPanel) == JFileChooser.APPROVE_OPTION) {
                    directory = "" + chooser.getSelectedFile();
                    default_Dir = true;
                    download.setEnabled(true);
                    download.setToolTipText(null);

                } else {
                    System.out.println("No Selection ");
                    default_Dir = false;
                }
            }
        });

        // Action Listener for the Text Box to manage user-input
        textUrl.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                domain = textUrl.getText();
                if (domain.length() == 0)
                    JOptionPane.showMessageDialog(newPanel, "Enter website name");
            }
        });

        // If check box is ticked, open website after download is complete
        checkbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                JCheckBox cb = (JCheckBox) event.getSource();
                if (cb.isSelected()) {
                    open = true;
                } else {
                    open = false;
                }
            }
        });

        // Action listener for the download button
        download.addActionListener(new ActionListener() {
            boolean started = false;

            public void actionPerformed(ActionEvent e) {

                domain = textUrl.getText();
                if (!domain.startsWith("http")) domain = filler + domain;

                try {
                    fw = new FileWriter("fileHistory.txt", true);
                    bw = new BufferedWriter(fw);
                    pw = new PrintWriter(bw);
                    dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm");
                    LocalDateTime now = LocalDateTime.now();
                    String localDir = directory + "\\Sites" + "\\" + domain.substring(8);
                    pw.print(dtf.format(now) + "\t    " + domain + "\t    " + localDir + "\n");
                    pw.flush();

                } catch (IOException io) {
                    io.printStackTrace();
                } finally {
                    try {
                        pw.close();
                        bw.close();
                        fw.close();
                    } catch (IOException io) {
                        io.printStackTrace();
                    }

                }

                if (!started) {
                    started = true;

                    JOptionPane.showMessageDialog(newPanel, "Download Started");

                    directory = directory.concat("\\Sites\\" + domain.substring(8));
                    FileManager fm = null;
                    try {
                        fm = new FileManager(directory, domain);
                    } catch (FileNotFoundException fileNotFoundException) {
                        fileNotFoundException.printStackTrace();
                    }
                    fm.makeDirectory();
                    DownloadThread dt = new DownloadThread(domain, newPanel, open, "website", directory);
                    try {
                        dt.download(domain);
                    } catch (IOException ex) {
                        //ex.printStackTrace();

                    }
                    // check if link can be accessed, then proceeds to download
                    if (dt.getGoodLink() == true) {
                        if (domain.startsWith("https:")) {
                            domain = domain.substring(8);
                        } else if (domain.startsWith("http:")) {
                            domain = domain.substring(7);
                        }
                        if (domain.startsWith("www")) {
                            domain = domain.substring(4);
                        }

                        try {
                            fm.findLinks();
                            fm.findCSS();
                            fm.findAndReplace(domain, directory);
                            JOptionPane.showMessageDialog(newPanel, "Download Complete");
                            if (open) {
                                dt.openFile(directory.concat("\\" + domain + ".html"));
                                //System.out.println(directory.concat("\""+domain + ".html"));

                            }
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    } else {
                        JOptionPane.showMessageDialog(newPanel, "Could not Find URL");
                    }
                }
                dispose();
            }
        });


        // Action Listener to terminate the program if pressed.
        cancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        // Set border for the panel
        newPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Download Panel"));

        // add the panel to this frame

        add(newPanel);

        pack();
        setLocationRelativeTo(null);
    }

    /**
     * Method to read settings.txt and load the settings into an ArrayList for further use
     */
    public void readSettings() {
        try (Scanner scanner = new Scanner(new FileReader("settings.txt"))) {
            while (scanner.hasNext()) {
                settingsArray.add(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}