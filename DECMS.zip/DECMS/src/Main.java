// DeCMS
// CSC3003S 2020

// Imports
import javax.swing.*;

/**
 * main class, starts the gui object.
 */
public class Main {

    /**
     * main method, starts the gui object.
     * @param args not used
     */
    public static void main(String[] args){

        // set look and feel to the system
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GUI().setVisible(true);
            }
        });
        //new Main();
    }
}
