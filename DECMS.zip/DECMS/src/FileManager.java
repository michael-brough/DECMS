// DeCMS
// CSC3003S 2020

// Imports
import java.io.*;
import java.util.*;

/**
 * class that reads and edits html, images, and styling files by reading the script and passing the information to the
 * downloadThread class.
 */
public class FileManager {
    private String directory;
    private String siteName;
    private String layer;
    private ArrayList<String> imageList = new ArrayList<>();
    private ArrayList<String> images = new ArrayList<>();

    /**
     * constructor that takes in directory and url for download and assigns them to instance variables
     *
     * @param directory the directory that the file will be downloaded to
     * @param domain    the URL from which the files will be downloaded
     * @throws IOException
     */
    public FileManager(String directory, String domain) throws FileNotFoundException {
        this.siteName = domain;
        this.directory = directory;
        this.layer = getLayer();
    }


    /**
     * method to create the root directory 'Sites' for the downloaded files.
     */
    public void makeDirectory() {
        String tempDir = directory.substring(0, directory.lastIndexOf("\\"));
        File siteFile = new File(tempDir);
        siteFile.mkdir();
        File file = new File(directory);
        file.mkdir();
    }

    /**
     * method that takes in a path string and creates a subdirectory with the same name
     * @param path the directory path of where the subdirectory must be created
     */
    public void subDirectory(String path) {
        File file = new File(this.directory.concat("\\" + path));
        file.mkdir();
    }

    /**
     * reads the settings file to check how many layers deep into the web page the program should download
     * @return
     * @throws FileNotFoundException
     */
    public String getLayer() throws FileNotFoundException {
        String data="";
        Scanner settings = new Scanner(new FileReader("settings.txt"));
        while (settings.hasNext()) {
            data = settings.nextLine();
            if(data.startsWith("linkLayers")){
                return data.substring(data.indexOf("=")+1);
            }
        }
        return data;
    }

    /**
     * This method extracts the .css links from the html
     * Then the css is added to the end of the domain name
     * Lastly, the the styling sheets can then be downloaded.
     * @throws IOException
     */
    public void findCSS() throws FileNotFoundException {
        subDirectory("styling");

        ArrayList<String> cssLinks = new ArrayList<>();
        File myObj = new File(directory.concat("\\htmlFull.html"));
        String data = "";

        Scanner myReader = new Scanner(myObj);
        //Reads through htmlFull.html to find all styling files and adds them to a list
        while (myReader.hasNext()) {
            data = myReader.next();
            if (data.length() > 10) {
                if(data.contains("css") && data.contains("href")){
                    //Test if has a protocol if not, it gets appended at the beginning
                    if(!data.contains("http") && data.contains(siteName)){
                        data = data.substring(6, findQuote(data));
                        data = "https:".concat(data);
                    }
                    else if (data.contains("http") && !data.contains(siteName)){
                        data = data.substring(6, findQuote(data));
                    }
                    //Appends protocol and site name if link is relative
                    else if(!data.contains("http") && !data.contains(siteName)){
                        data = data.substring(6, findQuote(data));
                        data = "https://"+siteName.concat(data);
                    }
                    else {
                        data = data.substring(6, findQuote(data));
                    }
                    data = data.substring(0, findQuote(data));
                    if(!cssLinks.contains(data)) cssLinks.add(data);
                }
            }
        }
        myReader.close();
        downloadCSS(cssLinks);
    }

    /**
     * method to generate the path that the styling files will be saved as
     * @param path path name which will be edited
     * @return
     */
    public String cssPath(String path){
        path = path.substring(path.lastIndexOf("/"));
        path = path.substring(0, findQuote(path));
        path = replaceCharacter(path);

        return path.concat(".css");
    }

    /**
     * method to start the download of a .css styling file
     * @param cssLinks
     */
    public void downloadCSS(ArrayList<String> cssLinks){
        for(int i=0;i<cssLinks.size();i++){
            String path = cssPath(cssLinks.get(i));
            Thread cssThread = new Thread(new DownloadThread(cssLinks.get(i), ".css", path, directory));
            cssThread.start();
        }
    }


    /**
     * method to find the location of the last quotation mark in a string
     * @param str
     * @return int location of character which can be read by string manipulation methods
     */
    public int findQuote(String str) {
        int position = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == '"') {
                position = i;
            }
        }
        if(position == 0)return str.length();
        else return position;
    }

    /**
     * method that searches an html document, and writes the embedded links to a separate text document 'links.txt'
     * @throws IOException
     */
    public void findLinks() throws IOException {
        //Creates links folder
        subDirectory("links");
        this.siteName = setSite(siteName);

        File linkFile = new File(this.directory.concat("\\links.txt"));
        ArrayList<String> links = new ArrayList<>();

        Scanner myReader = new Scanner(linkFile);
        //Reads theough links.txt to find all web links that are a part of the same domain name and trims the HTML tags
        //and add them to a list
        while (myReader.hasNext()) {
            String data = myReader.next();
            if (data.length() > 10) {

                if (data.startsWith("href=\"http") && data.contains(siteName)) {
                    data = data.substring(6, data.lastIndexOf("\""));
                    if(!links.contains(data))   links.add(data);
                }
                //Tests if link is relative
                else if(data.startsWith("href=\"/")){
                    data = data.substring(6);
                    data = "https://"+siteName+data;
                    data = data.substring(0, data.lastIndexOf("\""));
                    if(!links.contains(data))   links.add(data);
                }
            }
        }

        myReader.close();

        String fileName = "";
        ArrayList<String> linkPaths = new ArrayList<>();

        //Takes each element in the array and creates a new file and adds those file names to a separate array
        for (int i = 0; i < links.size(); i++) {

            if (links.get(i).substring(5, 7).equals("//")) {
                fileName = links.get(i).substring(7);
            } else {
                if (links.get(i).length() > 8) fileName = links.get(i).substring(8);
            }

            fileName = replaceCharacter(fileName);

            linkPaths.add(fileName);
            File file = new File(directory + "\\links\\" + fileName + ".html");
            file.createNewFile();

        }

        //Download links and calls findAndReplace method to replace the files references
        for (int i = 0; i < links.size() - 1; i++) {
            Thread linkThread = new Thread(new DownloadThread(links.get(i), "site", linkPaths.get(i), directory));
            linkThread.start();
            try {
                linkThread.join();
            } catch (Exception ex) {
                //ex.printStackTrace();
            }
            findAndReplace(links.get(i), linkPaths.get(i));
        }
    }

    /**
     * method to decrease the length of a filename if it is too long to be saved
     * @param filename
     * @return
     */
    public String cutString(String filename){
        if(filename.length() >=20){
            filename= filename.substring(filename.length()-20);
        }
        return filename;
    }

    /**
     * method to check if the string being read contains multiple links
     * this is common when javascript is being used
     * @param string
     * @return
     */
    public boolean isMultiLink(String string){
        if(string.contains("http")){
            string = string.substring(string.indexOf("http")+10);
            return string.length() > 10 && string.contains("http");
        }
        return false;
    }

    /**
     * method to find image links in an html file and starts a thread to download each.
     */
    public void findImages(String path) {

        try {
            //Creates images directory
            subDirectory("images");

            File file = new File(path);

            //Reads an HTML file as input
            Scanner myReader = new Scanner(file);
            while (myReader.hasNext()) {
                String data = myReader.next();
                int position = 0;
                if (data.length() > 10) {
                    //reads through the file to find image references, trims out the HTML tags and add it to an array list
                    if (data.contains("png") || data.contains("svg") || data.contains("jpg")) {
                        if(!isMultiLink(data) && !data.contains("w3") && data.contains("src")){
                            //Test if link is a relative one
                            if(!data.contains("http") && !data.contains(siteName)){
                                data = data.substring(5);
                                data = "https://".concat(siteName+data);
                            }
                            //Tests if link does not have a protocol
                            else if(!data.contains("http") && data.contains(siteName)){
                                data = data.substring(5);
                                data = "https://".concat(data);
                            }
                            else {
                                data = data.substring(data.lastIndexOf("http"));
                            }
                            position = findQuote(data);
                            data = data.substring(0, position);
                            //Prevents duplicate download
                            if(!images.contains(data)){
                                imageList.add(data);
                                images.add(data);

                            }
                        }
                    }
                }
            }
            myReader.close();
            //For loop to download the images
            for (int i=0;i<imageList.size();i++) {
                String filePath = imageList.get(i).substring(imageList.get(i).indexOf("/"));
                filePath = replaceCharacter(filePath);
                Thread imageThread = new Thread(new DownloadThread(imageList.get(i), "image", filePath, directory));
                imageThread.start();
                imageList.remove(i);
            }
        } catch (FileNotFoundException e) {
            //e.printStackTrace();
        }

    }

    /**
     * method to remove and replace characters that cannot be in filenames
     * @param str
     * @return
     */
    public String replaceCharacter(String str){
        str = str.replaceAll("/", "");
        str = str.replaceAll("\\?", "");
        str = str.replaceAll(":", "");
        return str.replaceAll("\\|", "");
    }

    /**
     * Reads robot.txt file to find which references should not be included in the locally hosted webpage
     * @param input
     * @return boolean
     * @throws FileNotFoundException
     */
    public boolean isDisallowed(String input) throws FileNotFoundException {
        String data = "";
        boolean test = false;
        File myObj = new File(this.directory.concat("\\robot.txt"));
        Scanner myReader = new Scanner(myObj);
        while (myReader.hasNext()) {
            data = myReader.next();
            if(data.equals("Disallow:") || test){
                test = true;
                if(input.contains(data)){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Removes https protocol from domain name
     * @param domain
     * @return siteName
     */
    public String setSite(String domain){
        if (domain.startsWith("https:")) {
            domain = domain.substring(8);
        } else if(domain.startsWith("http:")) {
            domain = domain.substring(7);
        }
        if (domain.startsWith("www")) {
            domain = domain.substring(4);
        }
        if(domain.contains("/")) domain.substring(0, domain.lastIndexOf("/"));
        return domain;
    }

    /**
     * method to generate the name of a file based on the agreed upon naming convention
     *
     * @param rawData the URL of the file which will be transformed
     * @param extension the file extension
     */
    public String generatePath(String rawData, String extension){
        String path="";
        if(!extension.equals(".css")) {
            if (!rawData.substring(5, 7).equals("//")) rawData = rawData.substring(8);
            else rawData = rawData.substring(7);
        }
        else if(rawData.contains("http")){
            rawData = rawData.substring(rawData.lastIndexOf(".com") + 4);
        }


        int position = findQuote(rawData);
        path = replaceCharacter(rawData.substring(0, position));
        if(extension.equals(".html"))    path = path.concat(extension);
        path = path.concat(rawData.substring(position));

        return path;
    }

    /**
     * method that searches an html file for references to embedded links, images, and styling, replacing them with
     * the local file locations
     *
     * @param linkUrl the URL of the file's reference that should be replaced
     * @param path    the directory of the files
     * @throws IOException
     */
    public void findAndReplace(String linkUrl, String path) throws IOException {
        //Creates newLinks folder
        subDirectory("links\\newLinks");

        String link = "href=\"http";

        FileWriter myWriter;
        File file;
        if(linkUrl.equals(siteName)){
            //Read htmlFull.html and write the new local references to 'sitename'.html
            myWriter = new FileWriter(directory.concat("\\"+siteName+".html"));
            file = new File(directory.concat("\\htmlFull.html"));
        }
        else{
            //Read the web references for files in links folder and create files in newLinks folder with new local references
            myWriter = new FileWriter(directory.concat("\\links\\newLinks\\"+path+".html"));
            file = new File(directory.concat("\\links\\"+path+".html"));
        }


        Scanner myReader = new Scanner(file);

        while (myReader.hasNext()) {
            String data = myReader.next();
            if(data.length() > 10 ) {
                //Searches for css file links on the HTML page and changes them to local references
                if (data.contains(".css")) {
                    if (data.substring(0,6).contains("href=\"")){
                        int position = findQuote(data);
                        myWriter.write("href=\"" + directory.concat("\\styling\\" + cssPath(data).concat(data.substring(position))));
                    }
                    else myWriter.write(data);
                }
                //searches for web links inside the paes and changes them to local links
                else if (data.substring(0, 10).equals(link)) {
                    if(data.contains(siteName)){
                        data = generatePath(data.substring(6), ".html");
                        myWriter.write("href=\"" + directory.concat("\\links\\newLinks\\"+data));
                        if(linkUrl.equals(siteName) && layer.equals("One")){
                            findImages(directory.concat("\\links\\"+data.substring(0, data.lastIndexOf("\""))));
                        }
                    }
                    else myWriter.write(data);
                }
                //Searchs for image references and changes them from web links to local references
                else if (data.contains("png") || data.contains("svg") || data.contains("jpg")) {
                    if(!isMultiLink(data) && !data.contains("w3") && data.contains("src")){
                        data = replaceCharacter(data.substring(data.indexOf("/")));
                        myWriter.write("src=\"" + directory.concat("\\images\\" + data));
                    }
                    else myWriter.write(data);
                }

                else myWriter.write(data);
            }
            else myWriter.write(data);
            myWriter.write(System.getProperty( "line.separator" ));
        }
        myReader.close();
        myWriter.close();
    }
}