// DeCMS
// CSC3003S 2020

// Imports
import java.awt.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * GUI class, extends JFrame
 * Serves as main User Interface from which the other GUI windows can be accessed.
 * This GUI contains a Menu Bar similar to most desktop applications for User Experience Design
 * This GUI also contains a box in which recently downloaded websites will appear, double clicking on any of the entries
 * will open the appropriate file location
 *
 * @throws IOException
 */
public class GUI extends JFrame {

    private JPanel newPanel;
    private JPanel middlePanel;
    private JPanel settingsPanel;
    private JPanel bottomPanel;
    private JLabel instructionLabel;
    private JFileChooser chooser = new JFileChooser();
    private JLabel headingLabel;
    private JList jList;
    private String chooserTitle;
    private ArrayList history;
    private GridBagConstraints gbc;
    private JScrollPane scrollPane;
    private FileWriter fw;
    private SettingsGUI settingsGui;
    private ArrayList<String> settingsArray;
    private PrintWriter pw;


    /**
     * Default Constructor for the GUI Class
     * Sets up GUI components and checks for UI updates every 2 seconds
     */
    public GUI() {
        initUI();
        //Use a timer to update the label at a fixed interval
        int delay = 2000;
        Timer timer = new Timer( delay, e -> {
            refreshJList();
        } );
        timer.start();
        // Create Settings File if it does not exist
        try {
            fw = new FileWriter("settings.txt", true); // append mode because if the file exists, it should not be altered
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to initialise the GUI components
     */
    private void initUI() {

        createMenuBar();
        setUpPanel();
        setTitle("DeCMS Website Archiver");
        setSize(550, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.BLUE);
        setVisible(true);
        settingsArray = new ArrayList<>();
        writeDefaultSettings();
    }

    /**
     * Method to Configure and Add the Menu Bar to the GUI Frame
     * Also adds functionality to each of the JMenu options
     */
    private void createMenuBar() {

        var menuBar = new JMenuBar();
        var fileMenu = new JMenu("File");
        var editMenu = new JMenu("Edit");
        var helpMenu = new JMenu("Help");

        var newURL = new JMenuItem("New URL", new ImageIcon("new.gif"));
        newURL.setToolTipText("Start a New Download");

        var openUrl = new JMenuItem("Open", new ImageIcon("open.gif"));
        newURL.setToolTipText("Open In Browser");

        var settings = new JMenuItem("Settings");

        var exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.setToolTipText("Exit application");

        var clearHistItem = new JMenuItem("Clear Recent Download History");
        clearHistItem.setToolTipText("Clears your recent Download History displayed below");

        var viewReadMe = new JMenuItem("View ReadMe");

        exitMenuItem.addActionListener((event) -> System.exit(0));

        fileMenu.add(newURL);
        fileMenu.add(openUrl);
        fileMenu.add(settings);
        fileMenu.add(exitMenuItem);
        editMenu.add(clearHistItem);
        helpMenu.add(viewReadMe);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);

        // opens the downloadGUI interface when clicked
        newURL.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DownloadGUI downloadBox = new DownloadGUI();
                downloadBox.setVisible(true);
            }
        });

        // opens a file chooser for .html files to allow the user to open any .html file in their default browser
        openUrl.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //chooser = new JFileChooser();
                chooser.setDialogTitle(chooserTitle);
                FileNameExtensionFilter restrict = new FileNameExtensionFilter("Only .html files", "html");
                chooser.addChoosableFileFilter(restrict);
                chooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                // Disable the "all files" option
                chooser.setAcceptAllFileFilterUsed(false);

                if (chooser.showOpenDialog(newPanel) == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = chooser.getSelectedFile();
                    Desktop desktop = Desktop.getDesktop();
                    if (selectedFile.exists())         //checks file exists or not
                    {
                        try {
                            desktop.open(selectedFile);
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    }
                }
            }
        });

        // clears the recent history box of any content
        clearHistItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                PrintWriter writer = null;
                try {
                    File fileHistory = new File("fileHistory.txt");
                    writer = new PrintWriter(fileHistory);
                } catch (FileNotFoundException fileNotFoundException) {
                    fileNotFoundException.printStackTrace();
                }
                writer.print("");
                writer.close();
                refreshJList();
            }
        });

        // opens the settings User Interface
        settings.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                settingsGui = new SettingsGUI();
            }
        });

        // opens the readme file using the default application for .txt files
        viewReadMe.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File file = new File("README.txt");
                if (!Desktop.isDesktopSupported()) //check if Desktop is supported by Platform or not
                {
                    System.out.println("not supported");
                    return;
                }
                Desktop desktop = Desktop.getDesktop();
                if (file.exists()) {
                    try {
                        desktop.open(file);
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "README.txt Not Found");
                }
            }
        });
    }

    /**
     * Method to configure and instantiate the GUI panels and add components to them
     */
    private void setUpPanel() {
        newPanel = new JPanel();
        newPanel.setBackground(new Color(0xFFFFFF));
        add(newPanel, BorderLayout.NORTH);
        //newPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Welcome to DeCMS"));
        newPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        headingLabel = new JLabel("Welcome to DeCMS!");

        newPanel.add(headingLabel);
        //newPanel.add(instructionLabel);

        middlePanel = new JPanel();
        instructionLabel = new JLabel("Use the Menu Bar to Select an Action");
        bottomPanel = new JPanel(new GridBagLayout());
        bottomPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Recent Download History"));
        middlePanel.add(instructionLabel);
        add(middlePanel);
        configureJList();
        bottomPanel.setBackground(new Color(0xFFFFFFFF, true));
        add(bottomPanel);
    }

    /**
     * Method to configure the JList object which displays the recent download history.
     */
    public void configureJList() {

        gbc = new GridBagConstraints();
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        jList = new JList<>();
        history = new ArrayList<String>();
        DefaultListModel dlm = new DefaultListModel();

        // populate JList
        File fileHistory = new File("fileHistory.txt");
        try {
            fw = new FileWriter("fileHistory.txt", true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Scanner readFile = null;
        try {
            readFile = new Scanner(fileHistory);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        while (readFile.hasNextLine()) {
            int i = 0;
            dlm.add(i, readFile.nextLine());
            i++;

        }

        jList.setModel(dlm);
        jList.setVisibleRowCount(5);
        scrollPane = new JScrollPane(jList, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setPreferredSize(new Dimension(600, 600));
        bottomPanel.add(jList, gbc);
        add(bottomPanel); // add scroll pane to frame

        // add listener for mouse clicks on specific JList items
        // when clicked, the respective file location is opened
        MouseListener mouseListener = new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {


                    String selectedItem = (String) jList.getSelectedValue();
                    //
                    selectedItem = selectedItem.substring(selectedItem.indexOf("\\") - 2);
                    //System.out.println(selectedItem);
                    try {
                        Desktop.getDesktop().open(new File(selectedItem));
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }

                }
            }
        };
        jList.addMouseListener(mouseListener);

    }

    /**
     * Method to refresh the contents of the JList box without remaking the JList object
     */
    public void refreshJList() {
        // now refresh the JList

        DefaultListModel dlm = new DefaultListModel();
        File fileHistory = new File("fileHistory.txt");
        Scanner readFile = null;
        try {
            readFile = new Scanner(fileHistory);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }

        while (readFile.hasNextLine()) {
            int i = 0;
            dlm.add(i, readFile.nextLine());
            i++;

        }
        jList.setModel(dlm);
    }

    /**
     * Method to Set up the Settings file with default values if it is either empty or does not yet exist
     */
    public void writeDefaultSettings(){
        if(new File("settings.txt").length() == 0){
            writeSettingToFile(0, "default_dir=null");
            writeSettingToFile(1, "dir_settings_changed=false");
            writeSettingToFile(2, "userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)");
            writeSettingToFile(3, "linkLayers=One");
            settingsArray.clear();
        }
    }

    /**
     * Method to write changed settings to the settings.txt file
     * @param index the line number where the settings should be changed
     * @param value the new setting string
     * @throws NullPointerException
     */
    public void writeSettingToFile(int index, String value) throws NullPointerException{
        // tries to set value to a specific index value, if out of bounds, adds the entry to the end of the list instead
        try{
            settingsArray.set(index, value);
        }
        catch(IndexOutOfBoundsException indexOutOfBoundsException){
            settingsArray.add(value);
        }
        // write the ArrayList to the settings file
        try {
            pw = new PrintWriter("settings.txt");

            for (int i = 0; i < settingsArray.size(); i++) {
                pw.println(settingsArray.get(i));
            }
            pw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}